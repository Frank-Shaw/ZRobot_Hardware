#include <stdint.h>

typedef signed char int8_t;
typedef unsigned char   uint8_t;
typedef short  int16_t;
typedef unsigned short  uint16_t;
typedef int  int32_t;
typedef unsigned   uint32_t;
typedef long long  int64_t;
typedef unsigned long long   uint64_t;

typedef struct{
	/***** input port declare start*************/
	int16_t err_in;		//Q8 format

	int16_t kp_parameter;	//Q8 format
	int16_t ki_parameter;	//Q8 format

	int16_t out_max;	//Q8 format
	int16_t out_min; //Q8 format
	int32_t ui_limit;	//Q8 format
	uint8_t set_ui_temp_en;
	int32_t set_ui_temp;

	/***** input port declare end*************/

	/***** output port declare start*************/
	int16_t out;	//Q8 format
	uint8_t out_sign;
	uint16_t usign_out;

	/***** output port declare end*************/

}INTERFACE;
