#include "pid_ctrl.h"

int main(){
	char i;
 	int rtn = 0;
	INTERFACE io_port;

	int32_t err_in[12] = {-13, -10, -7, 5, 3, 0, 0, 0, 0, 0, 0, 0}; // Q4
	int32_t out[12] = {-26, -33, -37, -20, -19, -22, -22, -22, -22, -0, -0, -0}; // Q4


	io_port.kp_parameter = 256; //Q16 value = 5/8
	io_port.ki_parameter = 1 << 8; //Q16 value = 4/8

	io_port.out_max = 0x0FF;
	io_port.out_min = 0 - 0x0FF;

	io_port.ui_limit = ((int32_t)0x0FFFF) << 8;

	io_port.set_ui_temp_en = 0;

	for(i = 0; i < 12; i ++)
	{
		io_port.err_in = err_in[i];

		if(i == 9)
		{
			io_port.set_ui_temp_en = 1;
			io_port.set_ui_temp = 1;
		}
		else
		{
			io_port.set_ui_temp_en = 0;
		}

		pid_ctrl(&io_port);

		if(io_port.out != out[i])
		{
			rtn += 1;
			printf("%d\t", io_port.out);
			printf("%d\t", io_port.out_sign);
			printf("%d\n\r", io_port.usign_out);
		}
	}

	return rtn;

}
