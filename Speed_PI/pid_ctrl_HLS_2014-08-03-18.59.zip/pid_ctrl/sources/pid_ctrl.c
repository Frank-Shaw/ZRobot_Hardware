#include "pid_ctrl.h"

static int32_t ui_temp = 0;

void pid_ctrl(INTERFACE *io_port)
{
	int32_t up_temp = 0;
	int16_t out = 0;
	if(io_port->set_ui_temp_en == 1)
	{
		ui_temp = io_port->set_ui_temp;
	}
	else
	{
		ui_temp += 0;
	}

	/* proportion calculate*/
	up_temp = (int32_t) io_port->err_in * (int32_t)io_port->kp_parameter;
	/* integration calculate*/
	ui_temp +=(int32_t) io_port->err_in * (int32_t)io_port->ki_parameter;

	up_temp >>= 8; 	//(Q_in * Q8 = Q_(in + 32)) >> 8 = Q_in format
    if(up_temp > io_port->out_max)
    {
    	out = io_port->out_max;
    }
    else if(up_temp < io_port->out_min)
    {
    	out = io_port->out_min;
    }
    else
    {
    	out = up_temp;
    	if (ui_temp > io_port->ui_limit)
       	{
       		ui_temp = io_port->ui_limit;
       	}
       	else if (ui_temp < (0 - io_port->ui_limit))
       	{
       		ui_temp = 0 - io_port->ui_limit;
       	}
       	out += ui_temp >> 8;
       	if (out > io_port->out_max)
       	{
       			out = io_port->out_max;
       	}
       	else if (out < io_port->out_min)
       	{
       		out = io_port->out_min;
       	}
    }
    io_port->out = out;
    if(io_port->out < 0)
    {
    	io_port->usign_out =  - io_port->out;
    	io_port->out_sign = 1;
    }
    else
    {
    	io_port->usign_out = io_port->out;
    	io_port->out_sign = 0;
    }

}
