$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "82"
$LUT = "288"
$FF = "107"
$DSP = "2"
$BRAM ="0"
$SRL ="0"
#=== Final timing ===
$TargetCP = "10.000"
$CP = "5.898"
