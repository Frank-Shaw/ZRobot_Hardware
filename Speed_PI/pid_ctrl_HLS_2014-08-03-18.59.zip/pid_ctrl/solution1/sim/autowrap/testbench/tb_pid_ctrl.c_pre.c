# 1 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/tb_pid_ctrl.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/tb_pid_ctrl.c"
# 1 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/pid_ctrl.h" 1
# 1 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stdint.h" 1 3 4


# 1 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 1 3 4
# 24 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 3 4
# 1 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stddef.h" 1 3 4
# 324 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stddef.h" 3 4
typedef short unsigned int wchar_t;
# 353 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stddef.h" 3 4
typedef short unsigned int wint_t;
# 25 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 2 3 4


typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef short int16_t;
typedef unsigned short uint16_t;
typedef int int32_t;
typedef unsigned uint32_t;
typedef long long int64_t;
typedef unsigned long long uint64_t;


typedef signed char int_least8_t;
typedef unsigned char uint_least8_t;
typedef short int_least16_t;
typedef unsigned short uint_least16_t;
typedef int int_least32_t;
typedef unsigned uint_least32_t;
typedef long long int_least64_t;
typedef unsigned long long uint_least64_t;





typedef signed char int_fast8_t;
typedef unsigned char uint_fast8_t;
typedef short int_fast16_t;
typedef unsigned short uint_fast16_t;
typedef int int_fast32_t;
typedef unsigned int uint_fast32_t;
typedef long long int_fast64_t;
typedef unsigned long long uint_fast64_t;
# 66 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 3 4
  typedef int intptr_t;
# 75 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 3 4
  typedef unsigned int uintptr_t;




typedef long long intmax_t;
typedef unsigned long long uintmax_t;
# 4 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stdint.h" 2 3 4
# 2 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/pid_ctrl.h" 2

typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef short int16_t;
typedef unsigned short uint16_t;
typedef int int32_t;
typedef unsigned uint32_t;
typedef long long int64_t;
typedef unsigned long long uint64_t;

typedef struct{

 int16_t err_in;

 int16_t kp_parameter;
 int16_t ki_parameter;

 int16_t out_max;
 int16_t out_min;
 int32_t ui_limit;
 uint8_t set_ui_temp_en;
 int32_t set_ui_temp;




 int16_t out;
 uint8_t out_sign;
 uint16_t usign_out;



}INTERFACE;
# 2 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/tb_pid_ctrl.c" 2

int main(){
 char i;
  int rtn = 0;
 INTERFACE io_port;

 int32_t err_in[12] = {-13, -10, -7, 5, 3, 0, 0, 0, 0, 0, 0, 0};
 int32_t out[12] = {-26, -33, -37, -20, -19, -22, -22, -22, -22, -0, -0, -0};


 io_port.kp_parameter = 256;
 io_port.ki_parameter = 1 << 8;

 io_port.out_max = 0x0FF;
 io_port.out_min = 0 - 0x0FF;

 io_port.ui_limit = ((int32_t)0x0FFFF) << 8;

 io_port.set_ui_temp_en = 0;

 for(i = 0; i < 12; i ++)
 {
  io_port.err_in = err_in[i];

  if(i == 9)
  {
   io_port.set_ui_temp_en = 1;
   io_port.set_ui_temp = 1;
  }
  else
  {
   io_port.set_ui_temp_en = 0;
  }

  pid_ctrl(&io_port);

  if(io_port.out != out[i])
  {
   rtn += 1;
   printf("%d\t", io_port.out);
   printf("%d\t", io_port.out_sign);
   printf("%d\n\r", io_port.usign_out);
  }
 }

 return rtn;

}
