#pragma line 1 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/pid_ctrl.c"
#pragma line 1 "<built-in>"
#pragma line 1 "<command-line>"
#pragma line 1 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/pid_ctrl.c"
#pragma line 1 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/pid_ctrl.h" 1
#pragma line 1 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stdint.h" 1 3 4
#pragma empty_line
#pragma empty_line
#pragma line 1 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 1 3 4
#pragma line 24 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 3 4
#pragma line 1 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stddef.h" 1 3 4
#pragma line 324 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stddef.h" 3 4
typedef short unsigned int wchar_t;
#pragma line 353 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stddef.h" 3 4
typedef short unsigned int wint_t;
#pragma line 25 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 2 3 4
#pragma empty_line
#pragma empty_line
typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef short int16_t;
typedef unsigned short uint16_t;
typedef int int32_t;
typedef unsigned uint32_t;
typedef long long int64_t;
typedef unsigned long long uint64_t;
#pragma empty_line
#pragma empty_line
typedef signed char int_least8_t;
typedef unsigned char uint_least8_t;
typedef short int_least16_t;
typedef unsigned short uint_least16_t;
typedef int int_least32_t;
typedef unsigned uint_least32_t;
typedef long long int_least64_t;
typedef unsigned long long uint_least64_t;
#pragma empty_line
#pragma empty_line
#pragma empty_line
#pragma empty_line
#pragma empty_line
typedef signed char int_fast8_t;
typedef unsigned char uint_fast8_t;
typedef short int_fast16_t;
typedef unsigned short uint_fast16_t;
typedef int int_fast32_t;
typedef unsigned int uint_fast32_t;
typedef long long int_fast64_t;
typedef unsigned long long uint_fast64_t;
#pragma line 66 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 3 4
  typedef int intptr_t;
#pragma line 75 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/../../../../include/stdint.h" 3 4
  typedef unsigned int uintptr_t;
#pragma empty_line
#pragma empty_line
#pragma empty_line
#pragma empty_line
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
#pragma line 4 "c:\\program_files\\xilinx\\vivado_hls\\2014.2\\msys\\bin\\../lib/gcc/mingw32/4.6.2/include/stdint.h" 2 3 4
#pragma line 2 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/pid_ctrl.h" 2
#pragma empty_line
typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef short int16_t;
typedef unsigned short uint16_t;
typedef int int32_t;
typedef unsigned uint32_t;
typedef long long int64_t;
typedef unsigned long long uint64_t;
#pragma empty_line
typedef struct{
#pragma empty_line
 int16_t err_in;
#pragma empty_line
 int16_t kp_parameter;
 int16_t ki_parameter;
#pragma empty_line
 int16_t out_max;
 int16_t out_min;
 int32_t ui_limit;
 uint8_t set_ui_temp_en;
 int32_t set_ui_temp;
#pragma empty_line
#pragma empty_line
#pragma empty_line
#pragma empty_line
 int16_t out;
 uint8_t out_sign;
 uint16_t usign_out;
#pragma empty_line
#pragma empty_line
#pragma empty_line
}INTERFACE;
#pragma line 2 "C:/Users/niu/Desktop/ZRobot/pid_ctrl/sources/pid_ctrl.c" 2
#pragma empty_line
static int32_t ui_temp = 0;
#pragma empty_line
void pid_ctrl(INTERFACE *io_port)
{
 int32_t up_temp = 0;
 int16_t out = 0;
 if(io_port->set_ui_temp_en == 1)
 {
  ui_temp = io_port->set_ui_temp;
 }
 else
 {
  ui_temp += 0;
 }
#pragma empty_line
#pragma empty_line
 up_temp = (int32_t) io_port->err_in * (int32_t)io_port->kp_parameter;
#pragma empty_line
 ui_temp +=(int32_t) io_port->err_in * (int32_t)io_port->ki_parameter;
#pragma empty_line
 up_temp >>= 8;
    if(up_temp > io_port->out_max)
    {
     out = io_port->out_max;
    }
    else if(up_temp < io_port->out_min)
    {
     out = io_port->out_min;
    }
    else
    {
     out = up_temp;
     if (ui_temp > io_port->ui_limit)
        {
         ui_temp = io_port->ui_limit;
        }
        else if (ui_temp < (0 - io_port->ui_limit))
        {
         ui_temp = 0 - io_port->ui_limit;
        }
        out += ui_temp >> 8;
        if (out > io_port->out_max)
        {
          out = io_port->out_max;
        }
        else if (out < io_port->out_min)
        {
         out = io_port->out_min;
        }
    }
    io_port->out = out;
    if(io_port->out < 0)
    {
     io_port->usign_out = - io_port->out;
     io_port->out_sign = 1;
    }
    else
    {
     io_port->usign_out = io_port->out;
     io_port->out_sign = 0;
    }
#pragma empty_line
}
