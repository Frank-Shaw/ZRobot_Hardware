#!/bin/sh
# Vivado(TM)
# compile.sh: Vivado-generated Script for launching XSim application
# Copyright 1986-2014 Xilinx, Inc. All Rights Reserved.
# 
if [ -z "$PATH" ]; then
  PATH=%XILINX%\lib\%PLATFORM%;%XILINX%\bin\%PLATFORM%:C:/Program_Files/Xilinx/SDK/2014.2/bin;C:/Program_Files/Xilinx/Vivado/2014.2/ids_lite/ISE/bin/nt64;C:/Program_Files/Xilinx/Vivado/2014.2/ids_lite/ISE/lib/nt64
else
  PATH=%XILINX%\lib\%PLATFORM%;%XILINX%\bin\%PLATFORM%:C:/Program_Files/Xilinx/SDK/2014.2/bin;C:/Program_Files/Xilinx/Vivado/2014.2/ids_lite/ISE/bin/nt64;C:/Program_Files/Xilinx/Vivado/2014.2/ids_lite/ISE/lib/nt64:$PATH
fi
export PATH

if [ -z "$LD_LIBRARY_PATH" ]; then
  LD_LIBRARY_PATH=:
else
  LD_LIBRARY_PATH=::$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH

#
# Setup env for Xilinx simulation libraries
#
XILINX_PLANAHEAD=C:/Program_Files/Xilinx/Vivado/2014.2
export XILINX_PLANAHEAD
ExecStep()
{
   "$@"
   RETVAL=$?
   if [ $RETVAL -ne 0 ]
   then
       exit $RETVAL
   fi
}

ExecStep xelab -m64 --debug typical --relax --include c:/Users/niu/Desktop/Motor_Controller_IP/test_motor/test_motor.srcs/sources_1/ip/ila_0/labtools_general_components_lib_v2_0/hdl/verilog --include c:/Users/niu/Desktop/Motor_Controller_IP/test_motor/test_motor.srcs/sources_1/ip/ila_0/labtools_xsdb_slave_lib_v3_0/hdl/verilog --include c:/Users/niu/Desktop/Motor_Controller_IP/test_motor/test_motor.srcs/sources_1/ip/ila_0/ila_v4_0/hdl/verilog -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip --snapshot tb_test_top_behav --prj C:/Users/niu/Desktop/Motor_Controller_IP/test_motor/test_motor.sim/sim_1/behav/tb_test_top.prj   xil_defaultlib.tb_test_top   xil_defaultlib.glbl
